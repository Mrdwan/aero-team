<?php

return [
    'uri' => env('AERO_TEAM_URI', 'meet-the-team')
];