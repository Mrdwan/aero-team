<?php

namespace Mradwan\AeroTeam\Http\Requests\TeamMembers;

use Aero\Admin\Http\Requests\SeoFormRequest;

class CreateTeamMemberRequest extends SeoFormRequest
{
    protected $validated;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'content' => 'nullable|string',
            'content_type' => 'required|string',
            'additional_attributes' => 'array',
            'additional_attributes.*.key' => 'required|string|alpha_dash|max:255',
            'additional_attributes.*.value' => 'required|string|max:10000',
            'image' => 'sometimes|array',
            'image.id' => 'nullable|exists:images,id',
        ];
    }
}
