<?php

namespace Mradwan\AeroTeam\Http\Controllers;

use Aero\Routing\Controller;
use Illuminate\Http\Request;
use Mradwan\AeroTeam\Models\TeamMember;
use Mradwan\AeroTeam\Responses\AdminTeamMemberCreate;
use Mradwan\AeroTeam\Http\Requests\TeamMembers\CreateTeamMemberRequest;

class AdminTeamController extends Controller
{
    public function index()
    {
        return view('aero-team::admin.members.index', [
            'teamMembers' => TeamMember::paginate(15)
        ]);
    }

    public function create(Request $request)
    {
        return $this->process(AdminTeamMemberCreate::class, [
            'request' => $request,
            'teammember' => new TeamMember()
        ]);
    }

    public function store(CreateTeamMEmberRequest $request)
    {
        return $this->process(AdminTeamMemberStore::class, [
            'request' => $request,
            'teammember' => TeamMember::create($request->validated())
        ]);
    }
}
