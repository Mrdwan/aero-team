<?php

namespace Aerocargo\Blog\Responses;

use Aero\Responses\ResponseBuilder;
use Aerocargo\Blog\Models\TeamMember;
use Aerocargo\Blog\Responses\Steps\UpdateTeamMember;
use Aerocargo\Blog\Responses\Steps\UpdateTeamMemberAdditionalAttributes;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminTeamMemberStore extends ResponseBuilder
{
    protected static $steps = [
        UpdateTeamMember::class,
        UpdateTeamMemberAdditionalAttributes::class,
    ];

    public function __construct(Request $request, TeamMember $teammember)
    {
        $this->setParameters(compact('request', 'teammember'));
    }

    public function getRedirect(): ?RedirectResponse
    {
        return parent::getRedirect() ?: redirect()
            ->route('aero_team.admin.team.index', $this->getParameter('teammember'))
            ->with([
                'message' => __('A new Team member has been created.'),
            ]);
    }

    protected function formatContent(array $data): string
    {
        $content = $data['content'];

        if (isset($data['content_type']) && $data['content_type'] === 'advanced'
            && ! Str::startsWith($content, '<!-- advanced -->')) {
            $content = '<!-- advanced -->'.$content;
        }

        return $content ?: '';
    }
}
